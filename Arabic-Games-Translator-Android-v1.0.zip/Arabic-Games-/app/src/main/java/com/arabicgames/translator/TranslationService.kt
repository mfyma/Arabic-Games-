package com.arabicgames.translator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.chaquo.python.Python
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class TranslationService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val cancelled = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancelled.set(true)
                sendUpdate(0, 0, getString(R.string.translation_cancelled), STATE_CANCELLED, null)
                return START_NOT_STICKY
            }
            ACTION_START -> {
                cancelled.set(false)
                val inputDir = intent.getStringExtra(EXTRA_INPUT_DIR) ?: return START_NOT_STICKY
                val outputZip = intent.getStringExtra(EXTRA_OUTPUT_ZIP) ?: return START_NOT_STICKY
                val source = intent.getStringExtra(EXTRA_SOURCE) ?: "auto"
                val provider = intent.getStringExtra(EXTRA_PROVIDER) ?: "google"
                val endpoint = intent.getStringExtra(EXTRA_ENDPOINT) ?: ""
                val apiKey = intent.getStringExtra(EXTRA_API_KEY) ?: ""

                startForeground(NOTIFICATION_ID, buildNotification(0, getString(R.string.notification_title)))
                executor.execute {
                    runTranslation(inputDir, outputZip, source, provider, endpoint, apiKey)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun runTranslation(
        inputDir: String,
        outputZip: String,
        source: String,
        provider: String,
        endpoint: String,
        apiKey: String
    ) {
        try {
            val callback = object : PythonProgressCallback {
                override fun onProgress(done: Int, total: Int, message: String) {
                    val progress = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
                    val manager = getSystemService(NotificationManager::class.java)
                    manager.notify(NOTIFICATION_ID, buildNotification(progress, message))
                    sendUpdate(done, total, message, STATE_RUNNING, null)
                }

                override fun isCancelled(): Boolean = cancelled.get()
            }

            val module = Python.getInstance().getModule("translator_engine")
            val cachePath = File(filesDir, "translation_memory.json").absolutePath
            val resultText = module.callAttr(
                "translate_package",
                inputDir,
                outputZip,
                source,
                provider,
                endpoint,
                apiKey,
                callback,
                cachePath
            ).toString()

            val result = JSONObject(resultText)
            if (result.optBoolean("cancelled", false)) {
                sendUpdate(0, 0, getString(R.string.translation_cancelled), STATE_CANCELLED, null)
            } else {
                val summary = result.optString("summary", getString(R.string.translation_complete))
                sendUpdate(1, 1, summary, STATE_COMPLETE, outputZip)
            }
        } catch (error: Throwable) {
            val message = error.message ?: error.javaClass.simpleName
            sendUpdate(0, 0, message, STATE_FAILED, null)
        } finally {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun sendUpdate(done: Int, total: Int, message: String, state: String, outputZip: String?) {
        val update = Intent(ACTION_PROGRESS).apply {
            setPackage(packageName)
            putExtra(EXTRA_DONE, done)
            putExtra(EXTRA_TOTAL, total)
            putExtra(EXTRA_MESSAGE, message)
            putExtra(EXTRA_STATE, state)
            putExtra(EXTRA_OUTPUT_ZIP, outputZip)
        }
        sendBroadcast(update)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.translation_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_description)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(progress: Int, message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        return builder
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(message.take(120))
            .setSmallIcon(R.drawable.ic_translate)
            .setOnlyAlertOnce(true)
            .setOngoing(progress in 0..99)
            .setProgress(100, progress, false)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.arabicgames.translator.action.START"
        const val ACTION_CANCEL = "com.arabicgames.translator.action.CANCEL"
        const val ACTION_PROGRESS = "com.arabicgames.translator.action.PROGRESS"

        const val EXTRA_INPUT_DIR = "input_dir"
        const val EXTRA_OUTPUT_ZIP = "output_zip"
        const val EXTRA_SOURCE = "source"
        const val EXTRA_PROVIDER = "provider"
        const val EXTRA_ENDPOINT = "endpoint"
        const val EXTRA_API_KEY = "api_key"
        const val EXTRA_DONE = "done"
        const val EXTRA_TOTAL = "total"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_STATE = "state"

        const val STATE_RUNNING = "running"
        const val STATE_COMPLETE = "complete"
        const val STATE_FAILED = "failed"
        const val STATE_CANCELLED = "cancelled"

        private const val CHANNEL_ID = "translation_progress"
        private const val NOTIFICATION_ID = 1207
    }
}
