package com.arabicgames.translator

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var selectButton: Button
    private lateinit var startButton: Button
    private lateinit var cancelButton: Button
    private lateinit var exportButton: Button
    private lateinit var selectedFilesText: TextView
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var sourceSpinner: Spinner
    private lateinit var providerSpinner: Spinner
    private lateinit var endpointInput: EditText
    private lateinit var apiKeyInput: EditText

    private var inputDirectory: File? = null
    private var generatedZip: File? = null
    private var translationRunning = false

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != TranslationService.ACTION_PROGRESS) return
            val done = intent.getIntExtra(TranslationService.EXTRA_DONE, 0)
            val total = intent.getIntExtra(TranslationService.EXTRA_TOTAL, 0)
            val message = intent.getStringExtra(TranslationService.EXTRA_MESSAGE).orEmpty()
            val state = intent.getStringExtra(TranslationService.EXTRA_STATE).orEmpty()
            val percent = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0

            progressBar.progress = percent
            statusText.text = if (total > 0) "$message\n$done / $total — $percent%" else message

            when (state) {
                TranslationService.STATE_COMPLETE -> {
                    translationRunning = false
                    setControlsRunning(false)
                    generatedZip = intent.getStringExtra(TranslationService.EXTRA_OUTPUT_ZIP)?.let(::File)
                    exportButton.isEnabled = generatedZip?.isFile == true
                    Toast.makeText(this@MainActivity, R.string.translation_complete, Toast.LENGTH_LONG).show()
                }
                TranslationService.STATE_FAILED -> {
                    translationRunning = false
                    setControlsRunning(false)
                    Toast.makeText(this@MainActivity, R.string.translation_failed, Toast.LENGTH_LONG).show()
                }
                TranslationService.STATE_CANCELLED -> {
                    translationRunning = false
                    setControlsRunning(false)
                    Toast.makeText(this@MainActivity, R.string.translation_cancelled, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        configureSpinners()
        configureListeners()
        requestNotificationPermissionIfNeeded()
    }

    private fun bindViews() {
        selectButton = findViewById(R.id.selectButton)
        startButton = findViewById(R.id.startButton)
        cancelButton = findViewById(R.id.cancelButton)
        exportButton = findViewById(R.id.exportButton)
        selectedFilesText = findViewById(R.id.selectedFilesText)
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)
        sourceSpinner = findViewById(R.id.sourceSpinner)
        providerSpinner = findViewById(R.id.providerSpinner)
        endpointInput = findViewById(R.id.endpointInput)
        apiKeyInput = findViewById(R.id.apiKeyInput)
    }

    private fun configureSpinners() {
        val sourceNames = listOf(
            getString(R.string.lang_auto),
            getString(R.string.lang_french),
            getString(R.string.lang_english),
            getString(R.string.lang_russian),
            getString(R.string.lang_spanish),
            getString(R.string.lang_german),
            getString(R.string.lang_japanese),
            getString(R.string.lang_chinese)
        )
        sourceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sourceNames)
        sourceSpinner.setSelection(1)

        val providers = listOf(getString(R.string.provider_google), getString(R.string.provider_libre))
        providerSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, providers)
        providerSpinner.setSelection(0)
        providerSpinner.onItemSelectedListener = SimpleItemSelectedListener { position ->
            val libre = position == 1
            endpointInput.visibility = if (libre) View.VISIBLE else View.GONE
            apiKeyInput.visibility = if (libre) View.VISIBLE else View.GONE
        }
    }

    private fun configureListeners() {
        selectButton.setOnClickListener { openFilePicker() }
        startButton.setOnClickListener { startTranslation() }
        cancelButton.setOnClickListener {
            val intent = Intent(this, TranslationService::class.java).apply {
                action = TranslationService.ACTION_CANCEL
            }
            startService(intent)
        }
        exportButton.setOnClickListener { openSavePicker() }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/zip",
                "application/json",
                "text/plain",
                "application/octet-stream"
            ))
        }
        startActivityForResult(intent, REQUEST_INPUT_FILES)
    }

    private fun openSavePicker() {
        val zip = generatedZip ?: return
        if (!zip.isFile) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "Arabic_Translation.zip")
        }
        startActivityForResult(intent, REQUEST_OUTPUT_ZIP)
    }

    @Deprecated("Deprecated in Android API, retained to avoid an AndroidX dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQUEST_INPUT_FILES -> importSelectedDocuments(data)
            REQUEST_OUTPUT_ZIP -> data.data?.let(::saveGeneratedZip)
        }
    }

    private fun importSelectedDocuments(data: Intent) {
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (index in 0 until clip.itemCount) uris += clip.getItemAt(index).uri
        }
        data.data?.let { if (it !in uris) uris += it }
        if (uris.isEmpty()) return

        val jobDir = File(filesDir, "jobs/${System.currentTimeMillis()}/input")
        if (!jobDir.mkdirs() && !jobDir.isDirectory) {
            Toast.makeText(this, R.string.error_copy, Toast.LENGTH_LONG).show()
            return
        }

        var copied = 0
        uris.forEachIndexed { index, uri ->
            val displayName = queryDisplayName(uri) ?: "input_$index"
            val safeName = sanitizeFilename(displayName)
            val uniqueFile = uniqueDestination(jobDir, safeName)
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(uniqueFile).use { output -> input.copyTo(output) }
                } ?: error("No input stream")
                copied++
            } catch (_: Exception) {
                uniqueFile.delete()
            }
        }

        if (copied == 0) {
            jobDir.parentFile?.deleteRecursively()
            Toast.makeText(this, R.string.error_copy, Toast.LENGTH_LONG).show()
            return
        }

        inputDirectory = jobDir
        generatedZip = null
        exportButton.isEnabled = false
        selectedFilesText.text = getString(R.string.files_selected, copied)
        statusText.text = getString(R.string.status_ready)
        progressBar.progress = 0
    }

    private fun startTranslation() {
        val input = inputDirectory
        if (input == null || !input.isDirectory || input.listFiles().isNullOrEmpty()) {
            Toast.makeText(this, R.string.error_no_files, Toast.LENGTH_SHORT).show()
            return
        }

        val provider = if (providerSpinner.selectedItemPosition == 1) "libretranslate" else "google"
        val endpoint = endpointInput.text.toString().trim()
        if (provider == "libretranslate" && endpoint.isBlank()) {
            Toast.makeText(this, R.string.error_endpoint, Toast.LENGTH_LONG).show()
            return
        }

        val sourceCodes = arrayOf("auto", "fr", "en", "ru", "es", "de", "ja", "zh-CN")
        val source = sourceCodes[sourceSpinner.selectedItemPosition.coerceIn(sourceCodes.indices)]
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val output = File(input.parentFile, "Arabic_Translation_$timestamp.zip")
        generatedZip = null

        val serviceIntent = Intent(this, TranslationService::class.java).apply {
            action = TranslationService.ACTION_START
            putExtra(TranslationService.EXTRA_INPUT_DIR, input.absolutePath)
            putExtra(TranslationService.EXTRA_OUTPUT_ZIP, output.absolutePath)
            putExtra(TranslationService.EXTRA_SOURCE, source)
            putExtra(TranslationService.EXTRA_PROVIDER, provider)
            putExtra(TranslationService.EXTRA_ENDPOINT, endpoint)
            putExtra(TranslationService.EXTRA_API_KEY, apiKeyInput.text.toString())
        }

        translationRunning = true
        setControlsRunning(true)
        progressBar.progress = 0
        statusText.text = getString(R.string.notification_title)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
    }

    private fun saveGeneratedZip(destination: Uri) {
        val source = generatedZip ?: return
        try {
            contentResolver.openOutputStream(destination, "w")?.use { output ->
                source.inputStream().use { input -> input.copyTo(output) }
            } ?: error("No output stream")
            Toast.makeText(this, R.string.saved_success, Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, R.string.save_failed, Toast.LENGTH_LONG).show()
        }
    }

    private fun setControlsRunning(running: Boolean) {
        selectButton.isEnabled = !running
        startButton.isEnabled = !running
        cancelButton.isEnabled = running
        sourceSpinner.isEnabled = !running
        providerSpinner.isEnabled = !running
        endpointInput.isEnabled = !running
        apiKeyInput.isEnabled = !running
        if (running) exportButton.isEnabled = false
    }

    private fun queryDisplayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0) else null
        } finally {
            cursor?.close()
        }
    }

    private fun sanitizeFilename(name: String): String {
        val clean = name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim()
        return clean.ifBlank { "input_file" }.take(180)
    }

    private fun uniqueDestination(directory: File, filename: String): File {
        var candidate = File(directory, filename)
        if (!candidate.exists()) return candidate
        val dot = filename.lastIndexOf('.')
        val base = if (dot > 0) filename.substring(0, dot) else filename
        val ext = if (dot > 0) filename.substring(dot) else ""
        var index = 2
        while (candidate.exists()) {
            candidate = File(directory, "${base}_$index$ext")
            index++
        }
        return candidate
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(TranslationService.ACTION_PROGRESS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(progressReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(progressReceiver, filter)
    }

    override fun onStop() {
        try {
            unregisterReceiver(progressReceiver)
        } catch (_: IllegalArgumentException) {
            // Receiver was not registered.
        }
        super.onStop()
    }

    private class SimpleItemSelectedListener(
        private val onSelection: (Int) -> Unit
    ) : android.widget.AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
            onSelection(position)
        }
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
    }

    companion object {
        private const val REQUEST_INPUT_FILES = 1001
        private const val REQUEST_OUTPUT_ZIP = 1002
        private const val REQUEST_NOTIFICATIONS = 1003
    }
}
