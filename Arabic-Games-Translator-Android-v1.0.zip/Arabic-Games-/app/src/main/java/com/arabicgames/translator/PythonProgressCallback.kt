package com.arabicgames.translator

interface PythonProgressCallback {
    fun onProgress(done: Int, total: Int, message: String)
    fun isCancelled(): Boolean
}
