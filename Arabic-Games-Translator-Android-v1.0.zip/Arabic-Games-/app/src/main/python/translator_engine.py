"""Core translation engine embedded in the Android APK through Chaquopy.

The module intentionally uses only Python's standard library. It processes Ren'Py
translation sources, protects formatting placeholders, maintains a translation
memory, and exports a clean ZIP without stale compiled .rpymc files.
"""

from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import shutil
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Callable, Iterable

TARGET_LANGUAGE = "ar"
TARGET_LANGUAGE_NAME = "العربية"
MAX_REQUEST_CHARS = 4500
SAVE_MEMORY_EVERY = 250

TRANSLATE_HEADER_RE = re.compile(r"^(\s*translate\s+)(\S+)(\s+.+?:\s*)$")
NEW_LINE_RE = re.compile(r"^\s*new\s+")
ARABIC_RE = re.compile(r"[\u0600-\u06FF]")
WORD_RE = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿА-Яа-яЁё\u3040-\u30ff\u3400-\u9fff]")
FILE_LIKE_RE = re.compile(r"^[\w./\\-]+\.(?:png|jpe?g|webp|gif|ogg|mp3|wav|mp4|webm|rpy|rpym|rpymc|ttf|otf)$", re.I)

PROTECTED_PATTERNS = [
    re.compile(r"\{[^{}]*\}"),                    # Ren'Py text tags: {w}, {size=...}
    re.compile(r"\[[^\[\]]+\]"),                 # Ren'Py interpolation: [player_name]
    re.compile(r"%\([^)]+\)[#0 +\-.]*[A-Za-z]"), # Python named formatting
    re.compile(r"%(?:[#0 +\-.]*\d*(?:\.\d+)?)?[A-Za-z%]"),
    re.compile(r"https?://[^\s\"']+"),
    re.compile(r"\\[nrt\"']"),
]


class TranslationCancelled(Exception):
    pass


class Progress:
    def __init__(self, callback: Any):
        self.callback = callback

    def emit(self, done: int, total: int, message: str) -> None:
        if self.cancelled():
            raise TranslationCancelled()
        if self.callback is not None:
            self.callback.onProgress(int(done), int(total), str(message))

    def cancelled(self) -> bool:
        return bool(self.callback is not None and self.callback.isCancelled())


class TranslationMemory:
    def __init__(self, path: str):
        self.path = Path(path)
        self.data: dict[str, str] = {}
        self.pending = 0
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                self.data = {str(k): str(v) for k, v in raw.items()}
        except (OSError, ValueError, TypeError):
            self.data = {}

    @staticmethod
    def key(provider: str, source: str, text: str) -> str:
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return f"{provider}|{source}|ar|{digest}"

    def get(self, provider: str, source: str, text: str) -> str | None:
        return self.data.get(self.key(provider, source, text))

    def put(self, provider: str, source: str, text: str, translated: str) -> None:
        self.data[self.key(provider, source, text)] = translated
        self.pending += 1
        if self.pending >= SAVE_MEMORY_EVERY:
            self.save()

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)
        self.pending = 0


class Translator:
    def __init__(self, provider: str, source: str, endpoint: str, api_key: str, memory: TranslationMemory):
        self.provider = provider
        self.source = source or "auto"
        self.endpoint = endpoint.strip().rstrip("/")
        self.api_key = api_key.strip()
        self.memory = memory
        self.requests = 0
        self.cache_hits = 0
        self.failures: list[dict[str, str]] = []

    def translate(self, text: str) -> str:
        if not should_translate(text):
            return text
        cached = self.memory.get(self.provider, self.source, text)
        if cached is not None:
            self.cache_hits += 1
            return cached

        protected, placeholders = protect_tokens(text)
        if len(protected) > MAX_REQUEST_CHARS:
            chunks = split_long_text(protected, MAX_REQUEST_CHARS)
            translated_protected = "".join(self._request_with_retry(chunk) for chunk in chunks)
        else:
            translated_protected = self._request_with_retry(protected)
        translated = restore_tokens(translated_protected, placeholders)
        translated = translated.strip() if text.strip() == text else translated
        if not translated:
            raise RuntimeError("عاد محرك الترجمة بنص فارغ")
        self.memory.put(self.provider, self.source, text, translated)
        return translated

    def _request_with_retry(self, text: str) -> str:
        last_error: Exception | None = None
        for attempt in range(4):
            try:
                self.requests += 1
                if self.provider == "libretranslate":
                    return self._libretranslate(text)
                return self._google(text)
            except (OSError, ValueError, KeyError, IndexError, urllib.error.URLError) as error:
                last_error = error
                if attempt < 3:
                    time.sleep(1.5 * (2**attempt))
        raise RuntimeError(f"تعذر الاتصال بمحرك الترجمة: {last_error}")

    def _google(self, text: str) -> str:
        query = urllib.parse.urlencode({
            "client": "gtx",
            "sl": self.source,
            "tl": TARGET_LANGUAGE,
            "dt": "t",
            "q": text,
        })
        request = urllib.request.Request(
            "https://translate.googleapis.com/translate_a/single?" + query,
            headers={"User-Agent": "ArabicGamesTranslator/1.0 (Android)"},
        )
        with urllib.request.urlopen(request, timeout=35) as response:
            payload = json.loads(response.read().decode("utf-8"))
        return "".join(part[0] for part in payload[0] if part and part[0])

    def _libretranslate(self, text: str) -> str:
        if not self.endpoint:
            raise ValueError("رابط LibreTranslate غير موجود")
        url = self.endpoint if self.endpoint.endswith("/translate") else self.endpoint + "/translate"
        body: dict[str, Any] = {
            "q": text,
            "source": self.source,
            "target": TARGET_LANGUAGE,
            "format": "text",
        }
        if self.api_key:
            body["api_key"] = self.api_key
        request = urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "ArabicGamesTranslator/1.0"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=45) as response:
            payload = json.loads(response.read().decode("utf-8"))
        return str(payload["translatedText"])


def should_translate(text: str) -> bool:
    stripped = text.strip()
    if not stripped or ARABIC_RE.search(stripped):
        return False
    visible = stripped
    for pattern in PROTECTED_PATTERNS:
        visible = pattern.sub("", visible)
    if not WORD_RE.search(visible):
        return False
    if FILE_LIKE_RE.fullmatch(stripped):
        return False
    return True


def protect_tokens(text: str) -> tuple[str, list[str]]:
    spans: list[tuple[int, int]] = []
    for pattern in PROTECTED_PATTERNS:
        spans.extend(match.span() for match in pattern.finditer(text))
    if not spans:
        return text, []

    spans.sort()
    merged: list[tuple[int, int]] = []
    for start, end in spans:
        if merged and start < merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    output: list[str] = []
    placeholders: list[str] = []
    cursor = 0
    for index, (start, end) in enumerate(merged):
        output.append(text[cursor:start])
        token = text[start:end]
        placeholders.append(token)
        output.append(f"__AGPH_{index:04d}__")
        cursor = end
    output.append(text[cursor:])
    return "".join(output), placeholders


def restore_tokens(text: str, placeholders: list[str]) -> str:
    result = text
    for index, token in enumerate(placeholders):
        marker = f"__AGPH_{index:04d}__"
        result = result.replace(marker, token)
        # Some translation services add spaces around underscores.
        fuzzy = re.compile(rf"__\s*AGPH\s*_\s*{index:04d}\s*__", re.I)
        result = fuzzy.sub(lambda _: token, result)
    return result


def split_long_text(text: str, limit: int) -> list[str]:
    if len(text) <= limit:
        return [text]
    chunks: list[str] = []
    remaining = text
    while len(remaining) > limit:
        cut = max(remaining.rfind("\n", 0, limit), remaining.rfind(" ", 0, limit))
        if cut < limit // 3:
            cut = limit
        chunks.append(remaining[:cut])
        remaining = remaining[cut:]
    if remaining:
        chunks.append(remaining)
    return chunks


def parse_string_literal(line: str) -> tuple[str, str, str] | None:
    """Return prefix, decoded content and suffix for a final quoted literal."""
    quote_start = -1
    quote_char = ""
    escaped = False
    for index, char in enumerate(line):
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char in ('"', "'"):
            quote_start = index
            quote_char = char
            break
    if quote_start < 0:
        return None

    escaped = False
    quote_end = -1
    for index in range(quote_start + 1, len(line)):
        char = line[index]
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == quote_char:
            quote_end = index
    if quote_end <= quote_start:
        return None

    literal = line[quote_start : quote_end + 1]
    suffix = line[quote_end + 1 :]
    if suffix.strip() and not suffix.lstrip().startswith("#"):
        return None
    try:
        decoded = ast.literal_eval(literal)
    except (SyntaxError, ValueError):
        return None
    if not isinstance(decoded, str):
        return None
    return line[:quote_start], decoded, suffix


def encode_string_literal(text: str, quote_char: str = '"') -> str:
    encoded = json.dumps(text, ensure_ascii=False)
    if quote_char == '"':
        return encoded
    inner = encoded[1:-1].replace("'", "\\'").replace('\\"', '"')
    return "'" + inner + "'"


def count_rpym_entries(path: Path) -> int:
    count = 0
    in_strings = False
    for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        header = TRANSLATE_HEADER_RE.match(line)
        if header:
            in_strings = header.group(3).strip().startswith("strings:")
            continue
        if in_strings and not NEW_LINE_RE.match(line):
            continue
        parsed = parse_string_literal(line)
        if parsed and should_translate(parsed[1]):
            count += 1
    return count


def translate_rpym(
    source_path: Path,
    destination_path: Path,
    translator: Translator,
    progress: Progress,
    counters: dict[str, int],
    total: int,
) -> None:
    lines = source_path.read_text(encoding="utf-8-sig", errors="replace").splitlines(keepends=True)
    output: list[str] = []
    in_strings = False
    is_language_name = source_path.name.lower() == "lang_name.rpym"

    for line_number, line_with_end in enumerate(lines, 1):
        newline = "\n" if line_with_end.endswith("\n") else ""
        line = line_with_end[:-1] if newline else line_with_end
        if line.endswith("\r"):
            line = line[:-1]
            newline = "\r\n" if newline else "\r"

        header = TRANSLATE_HEADER_RE.match(line)
        if header:
            in_strings = header.group(3).strip().startswith("strings:")
            output.append(f"{header.group(1)}{TARGET_LANGUAGE}{header.group(3)}{newline}")
            continue

        if in_strings and not NEW_LINE_RE.match(line):
            output.append(line + newline)
            continue

        parsed = parse_string_literal(line)
        if not parsed:
            output.append(line + newline)
            continue

        prefix, text, suffix = parsed
        if is_language_name and NEW_LINE_RE.match(line):
            translated = TARGET_LANGUAGE_NAME
        elif not should_translate(text):
            output.append(line + newline)
            continue
        else:
            try:
                translated = translator.translate(text)
            except Exception as error:  # keep the source text, report the exact location
                translated = text
                counters["failed"] += 1
                translator.failures.append({
                    "file": str(source_path.name),
                    "line": str(line_number),
                    "error": str(error),
                    "text": text[:300],
                })

        quote = line[len(prefix)] if len(line) > len(prefix) and line[len(prefix)] in ('"', "'") else '"'
        output.append(prefix + encode_string_literal(translated, quote) + suffix + newline)
        counters["processed"] += 1
        counters["translated"] += int(translated != text)
        if counters["processed"] % 5 == 0 or counters["processed"] == total:
            progress.emit(counters["processed"], total, f"ترجمة {source_path.name} — السطر {line_number}")

    destination_path.parent.mkdir(parents=True, exist_ok=True)
    destination_path.write_text("".join(output), encoding="utf-8", newline="")


def translate_manifest(source_path: Path, destination_path: Path, translator: Translator) -> None:
    try:
        payload = json.loads(source_path.read_text(encoding="utf-8-sig"))
    except (ValueError, OSError):
        shutil.copy2(source_path, destination_path)
        return
    if not isinstance(payload, dict):
        shutil.copy2(source_path, destination_path)
        return

    payload["id"] = "translation_ar"
    payload["name"] = "الترجمة العربية"
    payload["language"] = "Arabic"
    payload["language_code"] = "ar"
    description = payload.get("description")
    if isinstance(description, str) and should_translate(description):
        try:
            payload["description"] = translator.translate(description)
        except Exception:
            pass
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    destination_path.write_text(json.dumps(payload, ensure_ascii=False, indent=4) + "\n", encoding="utf-8")


def translate_json_strings(value: Any, translator: Translator) -> Any:
    if isinstance(value, str):
        try:
            return translator.translate(value)
        except Exception:
            return value
    if isinstance(value, list):
        return [translate_json_strings(item, translator) for item in value]
    if isinstance(value, dict):
        return {key: translate_json_strings(item, translator) for key, item in value.items()}
    return value


def safe_extract_zip(zip_path: Path, destination: Path) -> None:
    destination = destination.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        for info in archive.infolist():
            member = Path(info.filename)
            if member.is_absolute() or ".." in member.parts:
                continue
            target = (destination / member).resolve()
            if destination not in target.parents and target != destination:
                continue
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)


def prepare_sources(input_dir: Path, work_dir: Path) -> Path:
    source_root = work_dir / "source"
    source_root.mkdir(parents=True, exist_ok=True)
    for item in input_dir.iterdir():
        if item.is_file() and item.suffix.lower() == ".zip":
            safe_extract_zip(item, source_root)
        elif item.is_file():
            shutil.copy2(item, source_root / item.name)
    return source_root


def build_report(translator: Translator, counters: dict[str, int], skipped_compiled: int) -> dict[str, Any]:
    return {
        "target_language": "Arabic",
        "target_code": TARGET_LANGUAGE,
        "processed_strings": counters["processed"],
        "translated_strings": counters["translated"],
        "failed_strings": counters["failed"],
        "translation_requests": translator.requests,
        "translation_memory_hits": translator.cache_hits,
        "skipped_compiled_rpymc": skipped_compiled,
        "failures": translator.failures,
        "notes": [
            "تم حذف ملفات .rpymc القديمة لأن Ren'Py يعيد بناءها من ملفات .rpym.",
            "قد تحتاج بعض الألعاب إلى خط يدعم العربية أو إعدادات RTL خاصة بها.",
        ],
    }


def translate_package(
    input_dir: str,
    output_zip: str,
    source_language: str,
    provider: str,
    endpoint: str,
    api_key: str,
    callback: Any,
    memory_path: str,
) -> str:
    progress = Progress(callback)
    memory = TranslationMemory(memory_path)
    translator = Translator(provider, source_language, endpoint, api_key, memory)
    counters = {"processed": 0, "translated": 0, "failed": 0}
    skipped_compiled = 0

    input_path = Path(input_dir)
    output_path = Path(output_zip)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="arabic_games_", dir=str(output_path.parent)) as temp_name:
        work_dir = Path(temp_name)
        source_root = prepare_sources(input_path, work_dir)
        destination_root = work_dir / "Arabic_Translation"
        destination_root.mkdir(parents=True, exist_ok=True)

        rpym_files = [path for path in source_root.rglob("*") if path.is_file() and path.suffix.lower() == ".rpym"]
        total = sum(count_rpym_entries(path) for path in rpym_files)
        total = max(total, 1)
        progress.emit(0, total, f"تم العثور على {len(rpym_files)} ملف Ren’Py")

        try:
            for source_file in source_root.rglob("*"):
                if progress.cancelled():
                    raise TranslationCancelled()
                if not source_file.is_file():
                    continue
                relative = source_file.relative_to(source_root)
                destination = destination_root / relative
                suffix = source_file.suffix.lower()

                if suffix == ".rpymc":
                    skipped_compiled += 1
                    continue
                if suffix == ".rpym":
                    translate_rpym(source_file, destination, translator, progress, counters, total)
                elif source_file.name.lower() == "manifest.json":
                    translate_manifest(source_file, destination, translator)
                else:
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source_file, destination)

            report = build_report(translator, counters, skipped_compiled)
            (destination_root / "translation_report.json").write_text(
                json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
            (destination_root / "README_AR.txt").write_text(
                "حزمة ترجمة عربية مولّدة بواسطة Arabic Games Translator.\n"
                "انسخ محتويات الحزمة إلى مكان حزمة الترجمة في اللعبة.\n"
                "لم تُضمّن ملفات .rpymc القديمة، لأن Ren'Py يعيد توليدها تلقائيًا.\n",
                encoding="utf-8",
            )

            temp_zip = output_path.with_suffix(output_path.suffix + ".tmp")
            with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
                for file_path in destination_root.rglob("*"):
                    if file_path.is_file():
                        archive.write(file_path, file_path.relative_to(work_dir))
            temp_zip.replace(output_path)
            memory.save()
            progress.emit(total, total, "اكتملت الترجمة وتجهيز الملف المضغوط")

            summary = (
                f"اكتملت الترجمة: {counters['translated']} نص، "
                f"وفشل {counters['failed']} نص. راجع translation_report.json داخل الحزمة."
            )
            return json.dumps({"cancelled": False, "summary": summary, "output": str(output_path)}, ensure_ascii=False)
        except TranslationCancelled:
            memory.save()
            if output_path.exists():
                output_path.unlink()
            return json.dumps({"cancelled": True, "summary": "تم إلغاء العملية"}, ensure_ascii=False)
