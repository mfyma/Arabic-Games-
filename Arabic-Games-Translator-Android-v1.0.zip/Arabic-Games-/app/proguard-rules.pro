# Chaquopy and the app use no reflection-sensitive minification in release 1.0.
