import json
import tempfile
import unittest
import zipfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))
import translator_engine as engine


class FakeCallback:
    def __init__(self):
        self.events = []
    def onProgress(self, done, total, message):
        self.events.append((done, total, message))
    def isCancelled(self):
        return False


class FakeTranslator(engine.Translator):
    def _request_with_retry(self, text):
        return "AR:" + text


class TranslatorEngineTests(unittest.TestCase):
    def test_placeholder_round_trip(self):
        source = "Hello {w}[name] %(count)d\\nhttps://example.com"
        protected, values = engine.protect_tokens(source)
        self.assertNotIn("{w}", protected)
        restored = engine.restore_tokens(protected, values)
        self.assertEqual(source, restored)

    def test_should_skip_files_and_punctuation(self):
        self.assertFalse(engine.should_translate("...{w}..."))
        self.assertFalse(engine.should_translate("image.webp"))
        self.assertTrue(engine.should_translate("Bonjour le monde"))

    def test_translate_rpym_and_keep_old_strings(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "fr.rpym"
            target = root / "ar.rpym"
            source.write_text(
                'translate fr greeting_123:\n'
                '    hero "Bonjour {w}[name]"\n'
                'translate fr strings:\n'
                '    old "Start"\n'
                '    new "Commencer"\n',
                encoding="utf-8",
            )
            memory = engine.TranslationMemory(str(root / "memory.json"))
            translator = FakeTranslator("google", "fr", "", "", memory)
            counters = {"processed": 0, "translated": 0, "failed": 0}
            engine.translate_rpym(source, target, translator, engine.Progress(FakeCallback()), counters, 2)
            result = target.read_text(encoding="utf-8")
            self.assertIn("translate ar greeting_123:", result)
            self.assertIn('hero "AR:Bonjour {w}[name]"', result)
            self.assertIn('old "Start"', result)
            self.assertIn('new "AR:Commencer"', result)

    def test_package_removes_rpymc_and_updates_manifest(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            input_dir = root / "input"
            input_dir.mkdir()
            (input_dir / "lang_name.rpym").write_text(
                'translate fr strings:\n    old "{#language_name}"\n    new "French"\n', encoding="utf-8"
            )
            (input_dir / "old.rpymc").write_bytes(b"compiled")
            (input_dir / "manifest.json").write_text(json.dumps({
                "id": "translation_fr", "name": "French", "language": "French", "language_code": "fr"
            }), encoding="utf-8")
            output = root / "out.zip"

            original = engine.Translator._request_with_retry
            engine.Translator._request_with_retry = lambda self, text: "AR:" + text
            try:
                result = json.loads(engine.translate_package(
                    str(input_dir), str(output), "fr", "google", "", "", FakeCallback(), str(root / "memory.json")
                ))
            finally:
                engine.Translator._request_with_retry = original

            self.assertFalse(result["cancelled"])
            with zipfile.ZipFile(output) as archive:
                names = archive.namelist()
                self.assertFalse(any(name.endswith(".rpymc") for name in names))
                manifest = json.loads(archive.read("Arabic_Translation/manifest.json"))
                self.assertEqual("translation_ar", manifest["id"])
                self.assertEqual("ar", manifest["language_code"])
                lang_name = archive.read("Arabic_Translation/lang_name.rpym").decode("utf-8")
                self.assertIn('new "العربية"', lang_name)


if __name__ == "__main__":
    unittest.main()
